# GroupMe-Featherbeard

## Intro
A pirate-themed open-source GroupMe moderation bot written in Node.js.

DM or reach out to me (Alureon) on GroupMe with any questions, feedback, or ideas with my profile link [here](https://groupme.com/contact/93645911/a2jufjEF).

## Setup and Usage
Right now the easiest way to get started with Featherbeard and add him to your groups is to authorize him as an application for your GroupMe accout. From there you will be forwarded to his share link where you can add him to whatever groups you like! (Make sure you give him admin permissions first)

Visit https://featherbeard.alureon.dev/auth/ to authorize your account.
